/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED
 ** TO THE TENURES OF THE OHIO STATE UNIVERSITY'S ACADEMIC INTEGRITY POLICY
 ** WITH RESPECT TO THIS ASSIGNMENT
*/

//Name: Roy Acapulco

#include <stdio.h>
#include "lab4.h"

/* Reads File and uses insert to create LinkedList
 */
Node * readLinkedList(Node * list_head, FILE * oldFile) {

	//Dynamically allocate for a newNode
	Node * newNodePtr = (Node *)malloc(sizeof(Node));
	if (newNodePtr == NULL) {
		printf("Couldn't allocate enough space for list");       
		exit(EXIT_FAILURE);
	}

	//First if is to check if file has no items
	if (fscanf(oldFile,"%s\t", newNodePtr->grocery_item.item) != EOF) {
		
		//Then reads values into node, insert node then, using do while loop, checks if end of file
		do {
			fscanf(oldFile,"%s\t%d\t%f\t",newNodePtr->grocery_item.department, &(newNodePtr->grocery_item.stockNumber), &(newNodePtr->grocery_item.pricing.retailPrice));
			fscanf(oldFile,"%f\t%d\t%d",&(newNodePtr->grocery_item.pricing.wholesalePrice), &(newNodePtr->grocery_item.pricing.retailQuantity), &(newNodePtr->grocery_item.pricing.wholesaleQuantity));
			insert(newNodePtr,&list_head, oldFile);
			newNodePtr = (Node *)malloc(sizeof(Node));
			if (newNodePtr == NULL) {
				printf("Couldn't allocate enough space for list");       
				exit(EXIT_FAILURE);
			}
		} while (fscanf(oldFile, "\n%s", newNodePtr->grocery_item.item) != EOF);
	}
	//Makes sure to free last dynamically allocated newNodePtr
	free(newNodePtr);
	return list_head;
}
