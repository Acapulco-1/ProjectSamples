/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED
 ** TO THE TENURES OF THE OHIO STATE UNIVERSITY'S ACADEMIC INTEGRITY POLICY
 ** WITH RESPECT TO THIS ASSIGNMENT
*/

//Name: Roy Acapulco

#include <stdio.h>
#include "lab4.h"

/* Loops through a prompt, which uses numbers to determine the function called,
 * until user is ready to save into file
 */
void prompt(char *  date, char * saveFileName, Node * list_head) {
	int option = 0;

	//Sets breaks between 3 digits to be commas for US convention
	setlocale(LC_NUMERIC,"");

	//Array for replies to user input
	char * printf_array[12] = { "\nTotal revenue: $%'.2f\n",
				"\nTotal wholesale cost: $%'.2f\n",
				"\nTotal wholesale Investment: $%'.2f\n",
				"\nTotal profit: $%'.2f\n",
				"\nTotal number of grocery items sold: %0.f\n",
				"\nAverage Proft: $%'.2f\n",
				"\n",
				"\n",
				"\n",
				"\nPlease enter Additional Item:\n",
				"\nPlease enter Stock item for deletation\n"
				"\nAttempting to save file\n"};

	//first function pointer array that only requires Node * because of no manipulation
	float (*fp_array1[9])(Node *) = {opt1, opt2, opt3, opt4, opt5, opt6, opt7, opt8, opt9};

	//second function pointer array that uses Node ** because of Linked List manipulation
	void (*fp_array2[3])(Node **, char *, char *) = {opt10, opt11, opt12};
	
	//prompt loop
	while (option != 12) {
		//Used to not give unneccassary access to list_head for functions that don't need it
		Node * notListHead = list_head;

		//Prompt that gives list of options
		printf("Please enter an integer between 1 and 12:\n1) Print Total Revenue\n2) Print Total Wholesale Cost\n3) Print Current Grocery Item"
			"Investment\n4) Print Current Profit\n5) Print Total Number of Grocery Items Sold\n6) Print Average Profit Per Grocery Item\n7)"
			"Print Grocery Items In Stock\n8) Print Out of Stock Grocery Items\n9) Print Grocery Items for a Department\n10) Add Grocery Item"
			"to Inventory\n11) Delete Grocery Item from Inventoy\n12) Exit Program\n\noption: ");
		
		//reads in user choice then uses the appropriate array containing the correct function pointer
		scanf("%d", &option);
		if (option < 10) {
			printf(printf_array[option-1],fp_array1[option-1](notListHead));
		} else {
			printf(printf_array[option-1]);
			fp_array2[option-10](&list_head, saveFileName,date);
		}
	}
}
