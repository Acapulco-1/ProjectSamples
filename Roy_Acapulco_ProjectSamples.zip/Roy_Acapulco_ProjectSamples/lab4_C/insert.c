/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED
 ** TO THE TENURES OF THE OHIO STATE UNIVERSITY'S ACADEMIC INTEGRITY POLICY
 ** WITH RESPECT TO THIS ASSIGNMENT
*/

//Name: Roy Acapulco

#include <stdio.h>
#include "lab4.h"

/* Inserts node into appropriate part of the list
 */
void insert(Node * newNode, Node ** list_head, FILE * oldFile) {
	Node * traversePtr,* priorNode;
	if (*list_head == NULL) {
		*list_head = newNode;
		newNode->next = NULL;
	} else {
		if ((*list_head)->grocery_item.stockNumber >= newNode->grocery_item.stockNumber) {
			newNode->next = *list_head;
			*list_head = newNode;
			check(newNode->next->grocery_item.stockNumber,newNode->grocery_item.stockNumber, list_head, newNode, oldFile);
		}	
		else {
			traversePtr = (*list_head)->next;
			priorNode = (*list_head);	
			while (traversePtr != NULL &&
					traversePtr->grocery_item.stockNumber <= newNode->grocery_item.stockNumber) {	
				
				check(traversePtr->grocery_item.stockNumber,newNode->grocery_item.stockNumber, list_head, newNode, oldFile);
				priorNode = traversePtr;
				traversePtr = traversePtr->next;
			}
			newNode->next = traversePtr;
			priorNode->next = newNode;
		}
		
	}
}

