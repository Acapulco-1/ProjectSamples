/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED
 ** TO THE TENURES OF THE OHIO STATE UNIVERSITY'S ACADEMIC INTEGRITY POLICY
 ** WITH RESPECT TO THIS ASSIGNMENT
*/

//Name: Roy Acapulco

#include <stdio.h>
#include "lab4.h"

/* Returns wholesale cost as the sum of each item's wholesale price multiplied by their wholesale quantity
 */
float opt2 (Node *listHeadPtr) {

	//Uses traverse pointer to read through Linked List until NULL
	Node * traversePtr = listHeadPtr;
	float wholesaleCost = 0;
	while (traversePtr != NULL) {
		wholesaleCost += traversePtr->grocery_item.pricing.wholesalePrice *
			((float)traversePtr->grocery_item.pricing.wholesaleQuantity);
		traversePtr = traversePtr->next;
	}
	return wholesaleCost;
}

