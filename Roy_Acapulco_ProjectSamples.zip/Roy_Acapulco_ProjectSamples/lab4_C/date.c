/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED
 ** TO THE TENURES OF THE OHIO STATE UNIVERSITY'S ACADEMIC INTEGRITY POLICY
 ** WITH RESPECT TO THIS ASSIGNMENT
*/

//Name: Roy Acapulco

#include <stdio.h>
#include "lab4.h"

/* Uses either string or file to read in date that is converted into days
 */
int date(char * cliDate, FILE * fileDate) {
	
	int currentDay, currentMonth, currentYear;

	//changes read in function depending on which value is NULL
	if (cliDate == NULL) {
		fscanf(fileDate,"%d %d", &currentDay, &currentYear);
		currentMonth = 0;
	} else {
		sscanf(cliDate,"%d/%d/%d", &currentMonth, &currentDay, &currentYear);
	}

	//converts months into day, accounts for leap year
	for (int i = 1; i <= currentMonth; i++) {
		switch (i) {
			case 2:
			case 4:
			case 6:
			case 8:
			case 9:
			case 11:
				currentDay += 31;
				break;
			case 5:
			case 7:
			case 10:
			case 12:
				currentDay += 30;
				break;
			case 3:
				if (currentYear % 4 == 0) {
					currentDay += 29;
				} else {
					currentDay += 28;
				}
				break;
			case 1:
			case 0:
				break;
			default:
				printf("Please re-enter with valid month");
				break;
		}
	}
	//converts years into days, accounts for leap year
	currentDay += ((currentYear * 365)) + ((currentYear - 1) / 4);
	return currentDay;
}
