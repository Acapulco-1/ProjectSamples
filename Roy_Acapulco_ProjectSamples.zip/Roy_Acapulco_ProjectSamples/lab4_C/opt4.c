/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED
 ** TO THE TENURES OF THE OHIO STATE UNIVERSITY'S ACADEMIC INTEGRITY POLICY
 ** WITH RESPECT TO THIS ASSIGNMENT
*/

//Name: Roy Acapulco

#include <stdio.h>
#include "lab4.h"

/* Prints total profit using total revenue - (wholesale cost + current investment)
 */
float opt4 (Node *listHeadPtr) {

	//uses opt1 for revenue, opt2 for wholesale cost, and opt3 for current investment
	return (opt1(listHeadPtr) - (opt2(listHeadPtr) + opt3(listHeadPtr)));
}

