/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED
 ** TO THE TENURES OF THE OHIO STATE UNIVERSITY'S ACADEMIC INTEGRITY POLICY
 ** WITH RESPECT TO THIS ASSIGNMENT
*/

//Name: Roy Acapulco

#include <stdio.h>
#include "lab4.h"

/* Return total revene as the sum of the multiplication of retail price and retail quantity for each item
 */
float opt1 (Node *listHeadPtr) {
	
	//Uses traverse pointer to read through list until list is NULL
	Node * traversePtr = listHeadPtr;
	float revenue = 0;
	while (traversePtr != NULL) {
		revenue += traversePtr->grocery_item.pricing.retailPrice *
			((float)traversePtr->grocery_item.pricing.retailQuantity);
		traversePtr = traversePtr->next;
	}
	return revenue;
}

