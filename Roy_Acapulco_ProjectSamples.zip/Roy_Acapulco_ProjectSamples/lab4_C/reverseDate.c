/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED
 ** TO THE TENURES OF THE OHIO STATE UNIVERSITY'S ACADEMIC INTEGRITY POLICY
 ** WITH RESPECT TO THIS ASSIGNMENT
*/

//Name: Roy Acapulco

#include <stdio.h>
#include "lab4.h"

/* Takes in a MM/DD/YYYY string and prints to file DDD YYYY
 */
void reverseDate(char * cliDate, FILE * newFile) {
	
	int currentDay, currentMonth, currentYear;
	
	//reads in months, days, and years
	sscanf(cliDate,"%d/%d/%d", &currentMonth, &currentDay, &currentYear);

	//converts months to days, taking into account leap years
	for (int i = 1; i <= currentMonth; i++) {
		switch (i) {
			case 2:
			case 4:
			case 6:
			case 8:
			case 9:
			case 11:
				currentDay += 31;
				break;
			case 5:
			case 7:
			case 10:
			case 12:
				currentDay += 30;
				break;
			case 3:
				if (currentYear % 4 == 0) {
					currentDay += 29;
				} else {
					currentDay += 28;
				}
				break;
			case 1:
			case 0:
				break;
			default:
				printf("Please re-enter with valid month");
				break;
		}
	}

	//prints to file DDD YYYY
	fprintf(newFile, "%d %d\n", currentDay, currentYear);
}
