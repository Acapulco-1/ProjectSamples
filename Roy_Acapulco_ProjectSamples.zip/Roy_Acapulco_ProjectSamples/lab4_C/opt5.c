/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED
 ** TO THE TENURES OF THE OHIO STATE UNIVERSITY'S ACADEMIC INTEGRITY POLICY
 ** WITH RESPECT TO THIS ASSIGNMENT
*/

//Name: Roy Acapulco

#include <stdio.h>
#include "lab4.h"

/* Finds the sum sales by summing retail quantity
 */
float opt5 (Node *listHeadPtr) {

	//Uses traverse pointer to read through list until NULL
	Node * traversePtr = listHeadPtr;
	float sumSales = 0;
	while (traversePtr != NULL) {
		sumSales += (float)traversePtr->grocery_item.pricing.retailQuantity;
		traversePtr = traversePtr->next;
	}
	return sumSales;
}

