/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED
 ** TO THE TENURES OF THE OHIO STATE UNIVERSITY'S ACADEMIC INTEGRITY POLICY
 ** WITH RESPECT TO THIS ASSIGNMENT
*/

//Name: Roy Acapulco

#define _GNU_SOURCE
#include <stdio.h>
#include "lab4.h"

/* Takes input for a substring and uses substring to find departments whose name matches this substring
 */
float opt9 (Node *listHeadPtr) {

	//Uses traverse pointer to read through Linked List until NULL 
	Node * traversePtr = listHeadPtr;
	printf("Enter Department Name to print: ");
	
	//Statically allocated memory for substring, nothing in lab instructions said this must be dynamically allocated
	char subString[30];
	scanf("%s", subString);
	printf("Grocery Item List for %s:\nStock#\t\tQuantity\tDepartment\tItem\n", subString);
	while (traversePtr != NULL) {

		//uses strcasestr to check if inputted substring if substring of department string, ignoring case
		if (strcasestr((const char *)traversePtr->grocery_item.department,(const char *)subString) != NULL) {
			printf("%d\t\t%d\t\t%s\t\t%s\n", traversePtr->grocery_item.stockNumber,
					(traversePtr->grocery_item.pricing.wholesaleQuantity -
					traversePtr->grocery_item.pricing.retailQuantity),
					traversePtr->grocery_item.department,
					traversePtr->grocery_item.item);
		}
		traversePtr = traversePtr->next;
	}
	return 0;

}

