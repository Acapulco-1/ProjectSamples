/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED
 ** TO THE TENURES OF THE OHIO STATE UNIVERSITY'S ACADEMIC INTEGRITY POLICY
 ** WITH RESPECT TO THIS ASSIGNMENT
*/

//Name: Roy Acapulco

#include <stdio.h>
#include "lab4.h"

/* Adds new Node using user inputted information
 */
void opt10 (Node ** listHead, char * fileName, char * date) {
	
	//creates a new Node to read in data ...
	Node * newNodePtr = (Node *)malloc(sizeof(Node));
	if (newNodePtr == NULL) {
		printf("Couldn't allocate enough space for list");       
		exit(EXIT_FAILURE);
	}
	
	scanf("%s\t%s\t%d\t%f\t", newNodePtr->grocery_item.item, newNodePtr->grocery_item.department, &(newNodePtr->grocery_item.stockNumber), &(newNodePtr->grocery_item.pricing.retailPrice));
	scanf("%f\t%d\t%d",&(newNodePtr->grocery_item.pricing.wholesalePrice), &(newNodePtr->grocery_item.pricing.retailQuantity), &(newNodePtr->grocery_item.pricing.wholesaleQuantity));

	//... that is immediately inserted into the list using insert()
	insert(newNodePtr, listHead, NULL);
	return;
}

