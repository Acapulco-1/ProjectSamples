/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED
 ** TO THE TENURES OF THE OHIO STATE UNIVERSITY'S ACADEMIC INTEGRITY POLICY
 ** WITH RESPECT TO THIS ASSIGNMENT
*/

//Name: Roy Acapulco

#include <stdio.h>
#include "lab4.h"

/* Saves the new file with Linked List adding the given date as a header
 */
void opt12 (Node ** listHead, char * fileName, char * date) {
	
	//Attempts to open or create a new save file to write in
	FILE *saveFile;
	saveFile = fopen(fileName, "w");
	if (saveFile == NULL){
		printf("Can't open or find %s\n", fileName);
		exit(EXIT_FAILURE);
	}

	//prints out date in days time format for savefile
	reverseDate(date, saveFile);
	Node * traversePtr = NULL;
	while ((*listHead) != NULL) {

		//prints each node into list in stock number order
		fprintf(saveFile, "%s\t%s\t%d\t%f\t", (*listHead)->grocery_item.item, (*listHead)->grocery_item.department, (*listHead)->grocery_item.stockNumber, (*listHead)->grocery_item.pricing.retailPrice);
		fprintf(saveFile, "%f\t%d\t%d\n",(*listHead)->grocery_item.pricing.wholesalePrice, (*listHead)->grocery_item.pricing.retailQuantity, (*listHead)->grocery_item.pricing.wholesaleQuantity);
		
		//Makes traverse pointer point to listHead pointer node then frees it after listhead pointer is pointed to listhead pointer next
		traversePtr = *listHead;
		*listHead = (*listHead)->next;
		free(traversePtr);
	}

	//makes sure to close save file

	if (fclose(saveFile) != 0) {
		printf("failed to fclose %s\n", fileName);
		exit(EXIT_FAILURE);
	}	

	return;
}

