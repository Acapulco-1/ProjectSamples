/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED
 ** TO THE TENURES OF THE OHIO STATE UNIVERSITY'S ACADEMIC INTEGRITY POLICY
 ** WITH RESPECT TO THIS ASSIGNMENT
*/

//Name: Roy Acapulco

#include <stdio.h>
#include "lab4.h"

/* My main function that handles input checks and prompts the user if they want
 * to use the file given in the second argument
 */
int main (int argc, char **argv) {

	//Check for argument count
	if (argc != 4) {
		printf("Incorrect Amount Of Arguments.");
		exit(EXIT_FAILURE);
	}

	//Uses the second argument as the read in file
	FILE *oldFile;
	oldFile = fopen(argv[2], "r");
	if (oldFile == NULL){
		printf("Can't open or find %s\n", argv[2]);
		exit(EXIT_FAILURE);
	}

	//Compares both file date and argument date and asks user if they want to continue
	int testing = date(argv[1], NULL) - date(NULL, oldFile);

	printf("There are %d days difference between the date entered and the date in the file. Do you wish to continue?(y or n)", testing);

	

	char ask;
	scanf("%c", &ask);
	if (ask == 'y') {

		//creates a list_head as a Node *
		Node * list_head = NULL;

		//Reads through the file inserting an item into a linked list once a single node has read in all neccessary values
		printf("Reading inventory from file \"%s\"", argv[2]);
		list_head = readLinkedList(list_head, oldFile);

		//makes sure to close the file at the end, whether it was read or not.
		if (fclose(oldFile) != 0) {
			printf("failed to fclose %s\n", argv[2]);
			exit(EXIT_FAILURE);
		}

		//counts how many items were read in
		int count = countNodes(list_head);

		//Goes into the prompt list
		printf("A total of %d grocery items were read into inventory from the file \"%s\".\n", count, argv[2]);
		prompt(argv[1], argv[3], list_head);
		return 0;
	}

	//makes sure to close the file at the end, whether it was read or not.
	if (fclose(oldFile) != 0) {
			printf("failed to fclose %s\n", argv[2]);
			exit(EXIT_FAILURE);
	}

	return 0;
}
