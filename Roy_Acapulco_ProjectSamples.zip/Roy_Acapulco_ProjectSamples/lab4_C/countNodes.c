/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED
 ** TO THE TENURES OF THE OHIO STATE UNIVERSITY'S ACADEMIC INTEGRITY POLICY
 ** WITH RESPECT TO THIS ASSIGNMENT
*/

//Name: Roy Acapulco

#include <stdio.h>
#include "lab4.h"

/* Counts nodes inside linked list
 */
int countNodes(Node * listHeadPtr) {
	
	//uses a traverse pointer to count nodes
	Node * traversePtr = listHeadPtr;
	int count = 0;

	//...ending when traverse pointer is NULL
	while (traversePtr != NULL) {
		traversePtr = traversePtr->next;
		count++;
	}
	return count;
}
