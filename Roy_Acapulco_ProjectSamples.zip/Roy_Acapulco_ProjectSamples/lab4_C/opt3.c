/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED
 ** TO THE TENURES OF THE OHIO STATE UNIVERSITY'S ACADEMIC INTEGRITY POLICY
 ** WITH RESPECT TO THIS ASSIGNMENT
*/

//Name: Roy Acapulco

#include <stdio.h>
#include "lab4.h"

/* Return current investment which is the sum of wholesale price * (wholesale quantity - retail quantity)
 */
float opt3 (Node *listHeadPtr) {

	//Uses traverse pointer to read through Linked List until list is NULL
	Node * traversePtr = listHeadPtr;
	float currentInvestment = 0;
	while (traversePtr != NULL) {
		currentInvestment += traversePtr->grocery_item.pricing.wholesalePrice *
			(((float)traversePtr->grocery_item.pricing.wholesaleQuantity)
			 - ((float)traversePtr->grocery_item.pricing.retailQuantity));
		traversePtr = traversePtr->next;
	}
	return currentInvestment;
}

