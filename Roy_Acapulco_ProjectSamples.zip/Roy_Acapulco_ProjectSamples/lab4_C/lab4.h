/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED
 ** TO THE TENURES OF THE OHIO STATE UNIVERSITY'S ACADEMIC INTEGRITY POLICY
 ** WITH RESPECT TO THIS ASSIGNMENT
*/

//Name: Roy Acapulco

#include <stdlib.h>

//required for adding commas between 3 digits according to US standards
#include <locale.h>

//required to compare substring to string ignoring cases
#include <string.h>

//Values that can be reused with other items
struct Cost {
	float wholesalePrice;
	float retailPrice;
	int wholesaleQuantity;
	int retailQuantity;
};
//Values that are specific to a given item
struct Data {
	char item[50];
	char department[30];
	int stockNumber;
	struct Cost pricing;
};
//Node that is used to create a Linked List if items.
typedef struct Node {
	struct Data grocery_item;
	struct Node *next;
} Node;

void insert(Node * newNode, Node ** list_head, FILE * oldFile);
void check(int inputValue, int listValue, Node ** listHead, Node * newNode, FILE * oldFile);
int date(char * cliDate, FILE * fileDate);
Node * readLinkedList(Node * list_head, FILE * oldFile);
void prompt(char *  date, char * saveFileName, Node * list_head);
int countNodes(Node * list_head);

float opt1(Node *listHeadPtr);
float opt2(Node *listHeadPtr);
float opt3(Node *listHeadPtr);
float opt4(Node *listHeadPtr);	
float opt5(Node *listHeadPtr);
float opt6(Node *listHeadPtr);
float opt7(Node *listHeadPtr);
float opt8(Node *listHeadPtr);
float opt9(Node *listHeadPtr);

void opt10(Node **listHead,char * fileName, char * date);
void opt11(Node **listHead,char * fileName, char * date);
void opt12(Node **listHead,char * fileName, char * date);
void reverseDate(char * cliDate, FILE * newFile);
