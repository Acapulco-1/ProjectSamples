/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED
 ** TO THE TENURES OF THE OHIO STATE UNIVERSITY'S ACADEMIC INTEGRITY POLICY
 ** WITH RESPECT TO THIS ASSIGNMENT
*/

//Name: Roy Acapulco

#include <stdio.h>
#include "lab4.h"

/* Prints all in stock items
 */
float opt7 (Node *listHeadPtr) {

	//Uses traverse pointer to read through list until NULL
	Node * traversePtr = listHeadPtr;
	printf("Grocery items in Stock\nStock#\t\tQuantity\tDepartment\tItem\n");

	//Count is used to check if there no items read are in-stock
	int count = 0;
	while (traversePtr != NULL) {
		if ((traversePtr->grocery_item.pricing.wholesaleQuantity -
				traversePtr->grocery_item.pricing.retailQuantity) > 0) {
			printf("%d\t\t%d\t\t%s\t\t%s\n", traversePtr->grocery_item.stockNumber,
					(traversePtr->grocery_item.pricing.wholesaleQuantity -
					traversePtr->grocery_item.pricing.retailQuantity),
					traversePtr->grocery_item.department,
					traversePtr->grocery_item.item);
			count++;
		}
		traversePtr = traversePtr->next;
	}

	//Prints line if nothing is in-stock
	if (count == 0) {
		printf("No In-Stock Items.");
	}
	return 0;
}

