/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED
 ** TO THE TENURES OF THE OHIO STATE UNIVERSITY'S ACADEMIC INTEGRITY POLICY
 ** WITH RESPECT TO THIS ASSIGNMENT
*/

//Name: Roy Acapulco

#include <stdio.h>
#include "lab4.h"

/* Deletes Nodes given stock number
 */
void opt11 (Node ** listHead, char * fileName, char * date) {
	
	//Holds stock number to be deleted
	int stockNumber;
	scanf("%d",&stockNumber);

	//Uses traverse pointer and prior node to find and delete stock number
	Node *traversePtr, *priorNode;

	//Checks if list is empty
	if (*listHead == NULL) {
		check(stockNumber, -1, listHead, NULL, NULL);

		//checks if stock number is first item in list
	} else if ((*listHead)->grocery_item.stockNumber == stockNumber) {
		traversePtr = (*listHead);
		*listHead = (*listHead)->next;
	} else {
		
		//Puts prior Node prior to traverse pointer	
		priorNode = (*listHead);
		traversePtr = (*listHead)->next;

		//stops traversing list when traverse pointer is NULL or when the stockNumber is found
		while (traversePtr != NULL && traversePtr->grocery_item.stockNumber != stockNumber) {
			priorNode = traversePtr;
			traversePtr = traversePtr->next;
		}

		//Check for if list doesn't contain stock number
		if (traversePtr == NULL)
			check(stockNumber, -1, listHead, NULL, NULL);
		priorNode->next = traversePtr->next;
	}

	//makes sure to free Node to be deleted
	free(traversePtr);
	
	return;
}

