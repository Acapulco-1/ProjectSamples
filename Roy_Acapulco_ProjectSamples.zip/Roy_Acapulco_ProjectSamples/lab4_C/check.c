/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED
 ** TO THE TENURES OF THE OHIO STATE UNIVERSITY'S ACADEMIC INTEGRITY POLICY
 ** WITH RESPECT TO THIS ASSIGNMENT
*/

//Name: Roy Acapulco

#include <stdio.h>
#include "lab4.h"

/* Handles accidentental deletion of non-existant item and Check
 * if inserting item with same stock number. Quits and frees if yes
 */
void check (int inputValue, int listValue, Node ** listHead, Node * newNode, FILE * oldFile) {

	//First part is the insert() check the second part is opt11() (delete) check
	if (listValue == inputValue || listValue == -1) {
		//prints corrent error message depeding on circumstance
		if (listValue == -1) {
			printf("Can't find stock number %d\n", inputValue);
		} else if (listValue == inputValue) {
			printf("Inputted duplicate stock value %d\n", inputValue);

			if (oldFile != NULL && fclose(oldFile) != 0) {
				printf("failed to fclose old File\n");
				exit(EXIT_FAILURE);
			}
		}

		//frees all nodes currently in linked list
		Node * traversePtr;
		while ((*listHead) != NULL) {
			traversePtr = *listHead;
			*listHead = (*listHead)->next;
			free(traversePtr);
		}
		free(newNode);
		exit(EXIT_FAILURE);
	}

	return;
}

