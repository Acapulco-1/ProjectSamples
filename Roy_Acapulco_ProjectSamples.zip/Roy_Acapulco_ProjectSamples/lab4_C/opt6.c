/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED
 ** TO THE TENURES OF THE OHIO STATE UNIVERSITY'S ACADEMIC INTEGRITY POLICY
 ** WITH RESPECT TO THIS ASSIGNMENT
*/

//Name: Roy Acapulco

#include <stdio.h>
#include "lab4.h"

/* Return average profit by dividing total profit by sum of sales
 */
float opt6 (Node *listHeadPtr) {
	
	//opt4 is total profit and opt5 is number of sales
	return ((opt4(listHeadPtr))/(opt5(listHeadPtr)));
}

