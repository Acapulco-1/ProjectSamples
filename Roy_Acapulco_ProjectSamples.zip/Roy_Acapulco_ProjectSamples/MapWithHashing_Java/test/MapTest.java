import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.map.Map;

/**
 * JUnit test fixture for {@code Map<String, String>}'s constructor and kernel
 * methods.
 *
 * @author Roy Acapulco
 *
 */
public abstract class MapTest {

    /**
     * Invokes the appropriate {@code Map} constructor for the implementation
     * under test and returns the result.
     *
     * @return the new map
     * @ensures constructorTest = {}
     */
    protected abstract Map<String, String> constructorTest();

    /**
     * Invokes the appropriate {@code Map} constructor for the reference
     * implementation and returns the result.
     *
     * @return the new map
     * @ensures constructorRef = {}
     */
    protected abstract Map<String, String> constructorRef();

    /**
     *
     * Creates and returns a {@code Map<String, String>} of the implementation
     * under test type with the given entries.
     *
     * @param args
     *            the (key, value) pairs for the map
     * @return the constructed map
     * @requires <pre>
     * [args.length is even]  and
     * [the 'key' entries in args are unique]
     * </pre>
     * @ensures createFromArgsTest = [pairs in args]
     */
    private Map<String, String> createFromArgsTest(String... args) {
        assert args.length % 2 == 0 : "Violation of: args.length is even";
        Map<String, String> map = this.constructorTest();
        for (int i = 0; i < args.length; i += 2) {
            assert !map.hasKey(args[i]) : ""
                    + "Violation of: the 'key' entries in args are unique";
            map.add(args[i], args[i + 1]);
        }
        return map;
    }

    /**
     *
     * Creates and returns a {@code Map<String, String>} of the reference
     * implementation type with the given entries.
     *
     * @param args
     *            the (key, value) pairs for the map
     * @return the constructed map
     * @requires <pre>
     * [args.length is even]  and
     * [the 'key' entries in args are unique]
     * </pre>
     * @ensures createFromArgsRef = [pairs in args]
     */
    private Map<String, String> createFromArgsRef(String... args) {
        assert args.length % 2 == 0 : "Violation of: args.length is even";
        Map<String, String> map = this.constructorRef();
        for (int i = 0; i < args.length; i += 2) {
            assert !map.hasKey(args[i]) : ""
                    + "Violation of: the 'key' entries in args are unique";
            map.add(args[i], args[i + 1]);
        }
        return map;
    }

    // TODO - add test cases for constructor, add, remove, removeAny, value,
    // hasKey, and size

    /*
     * for size tests
     */
    private final int five = 5;

    /*
     * Test cases for constructor
     */

    @Test
    public final void testConstructorEmpty() {

        Map<String, String> q = this.createFromArgsTest();
        Map<String, String> qExpected = this.createFromArgsRef();

        assertEquals(qExpected, q);
    }

    @Test
    public final void testConstructorRoutine() {

        Map<String, String> q = this.createFromArgsTest("yellow", "2", "green",
                "3");
        Map<String, String> qExpected = this.createFromArgsRef("yellow", "2",
                "green", "3");

        assertEquals(qExpected, q);
    }

    /*
     * Test cases for add
     */

    @Test
    public final void testAdd() {

        Map<String, String> q = this.createFromArgsTest("red", "0", "orange",
                "1");
        Map<String, String> qExpected = this.createFromArgsRef("red", "0",
                "orange", "1", "yellow", "2");

        q.add("yellow", "2");

        assertEquals(qExpected, q);
    }

    @Test
    public final void testAddEmpty() {

        Map<String, String> q = this.createFromArgsTest();
        Map<String, String> qExpected = this.createFromArgsRef("white", "0");

        q.add("white", "0");

        assertEquals(qExpected, q);
    }

    /*
     * Test cases for remove
     */

    @Test
    public final void testRemove() {

        Map<String, String> q = this.createFromArgsTest("yellow", "3", "green",
                "4");
        Map<String, String> qExpected = this.createFromArgsRef("green", "4");

        q.remove("yellow");

        assertEquals(qExpected, q);
    }

    /*
     * Test cases for removeAny
     */

    @Test
    public final void testRemoveAny() {

        //Setup
        Map<String, String> q = this.createFromArgsTest("red", "0", "orange",
                "1", "yellow", "2");
        Map<String, String> qExpected = this.createFromArgsRef("red", "0",
                "orange", "1", "yellow", "2");

        //Call
        Map.Pair<String, String> removed = q.removeAny();

        //Evaluation
        assertEquals(qExpected.hasKey(removed.key()), true);

        Map.Pair<String, String> removedExpected = qExpected
                .remove(removed.key());

        assertEquals(removed, removedExpected);
    }

    @Test
    public final void testRemoveAnyOneItem() {

        //Setup
        Map<String, String> q = this.createFromArgsTest("red", "0");
        Map<String, String> qExpected = this.createFromArgsRef("red", "0");

        //Call
        Map.Pair<String, String> removed = q.removeAny();

        //Evaluation
        assertEquals(qExpected.hasKey(removed.key()), true);

        Map.Pair<String, String> removedExpected = qExpected
                .remove(removed.key());

        assertEquals(removed, removedExpected);
    }

    /*
     * Test cases for value
     */

    @Test
    public final void testValue() {

        Map<String, String> q = this.createFromArgsTest("yellow", "3", "green",
                "4");
        String qExpected = "4";

        assertEquals(qExpected, q.value("green"));
    }

    /*
     * Test cases for haskey
     */

    @Test
    public final void testHasKeyTrue() {

        Map<String, String> q = this.createFromArgsTest("yellow", "3", "green",
                "4", "blue", "5");

        assertEquals(true, q.hasKey("yellow"));
    }

    @Test
    public final void testHasKeyFalse() {

        Map<String, String> q = this.createFromArgsTest("yellow", "3", "green",
                "4", "blue", "5");

        assertEquals(false, q.hasKey("rainbow"));
    }

    /*
     * Test cases for size
     */

    @Test
    public final void testSizeRoutine() {

        Map<String, String> q = this.createFromArgsTest("yellow", "3", "green",
                "4", "blue", "5", "purple", "6", "colors", "10");
        int qExpected = this.five;

        assertEquals(qExpected, q.size());
    }

    @Test
    public final void testSizeEmpty() {

        Map<String, String> q = this.createFromArgsTest();
        int qExpected = 0;

        assertEquals(qExpected, q.size());
    }

}
